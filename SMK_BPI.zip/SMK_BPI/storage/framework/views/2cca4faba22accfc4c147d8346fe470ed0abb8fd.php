<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/bootstrap.min(1).css">    
    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" href="/siswa">Data Siswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/guru">Data Guru</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/gallery">Gallery</a>
                </li>
            </ul>
        </div>
    </nav>

    <img src="download.jpg">
</body>
</html><?php /**PATH D:\xampp\htdocs\laravel\SMK_BPI\resources\views/gallery.blade.php ENDPATH**/ ?>